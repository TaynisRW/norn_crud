<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class PermissionRoleTableSeeder extends Seeder
{
    public function run()
    {
        // Admin: user and personal information access
        Role::find(1)->permissions()->attach([1,2]);
        // User: onlyuser access
        Role::find(2)->permissions()->attach(2);
    }
}
