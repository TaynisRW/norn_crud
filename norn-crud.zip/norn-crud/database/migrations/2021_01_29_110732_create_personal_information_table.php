<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePersonalInformationTable extends Migration
{
    public function up()
    {
        Schema::create('personal_information', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->string('district');
            $table->string('suburb');
            $table->integer('external_number');
            $table->integer('internal_number')->nullable();
            $table->string('street');
            $table->softDeletes()->nullable();
            $table->timestamps();
        });
        Schema::table('personal_information', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users')
                    ->onDelete('set null');
        });
    }

    public function down()
    {
        Schema::dropIfExists('personal_information');
    }
}
