<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePersonalInformationRequest;
use App\Http\Requests\UpdatePersonalInformationRequest;
use App\Models\PersonalInformation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;

class PersonalInformationController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('personal_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // $personal = PersonalInformation::all();
        $personal = PersonalInformation::with('users')->get();

        return view('personal.index', compact('personal'));
    }

    public function create()
    {
        abort_if(Gate::denies('personal_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::pluck('name', 'id');

        return view('personal.create', compact('users'));
        // return view('personal.create');
    }

    public function store(StorePersonalInformationRequest $request)
    {
        // $user = PersonalInformation::create($request->validated());
        $user = PersonalInformation::create([
                'user_id' => rand(0,9),
                'district' => $request['district'],
                'suburb' => $request['suburb'],
                'external_number' => $request['external_number'],
                'internal_number' => $request['internal_number'],
                'street' => $request['street']
            ]);
        // $user->users()->attach($request->input('user_id', []));
        return redirect()->route('personal.index');
    }

    public function show(PersonalInformation $personal)
    {
        abort_if(Gate::denies('personal_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('personal.show', compact('personal'));
    }

    public function edit(PersonalInformation $personal)
    {
        abort_if(Gate::denies('personal_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('personal.edit', compact('personal'));
    }

    public function update(UpdatePersonalInformationRequest $request, PersonalInformation $personal)
    {
        $personal->update($request->validated());

        return redirect()->route('personal.index');
    }

    public function destroy($id)
    {
        abort_if(Gate::denies('personal_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $personalInformation =  PersonalInformation::find($id);

        $personalInformation->delete();

        return redirect()->route('personal.index');
    }
}
