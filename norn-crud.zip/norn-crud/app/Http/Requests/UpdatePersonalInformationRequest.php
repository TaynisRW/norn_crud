<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Gate;

class UpdatePersonalInformationRequest extends FormRequest
{
    public function rules()
    {
        return [
            'district' => [
                'required',
                'string'
            ],
            'suburb' => [
                'required',
                'string'
            ],
            'external_number' => [
                'required',
                'integer'
            ],
            'internal_number' => [
                'integer',
            ],
            'street' => [
                'required',
                'string',
            ]
        ];
    }

    public function authorize()
    {
        return Gate::allows('personal_access');
    }
}
