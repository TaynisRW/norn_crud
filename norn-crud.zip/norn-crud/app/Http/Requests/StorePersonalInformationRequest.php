<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Gate;

class StorePersonalInformationRequest extends FormRequest
{
    public function rules()
    {
        return [
            'user_id.*'  => [
                'integer',
            ],
            'user_id'    => [
                'required',
                'array',
            ],
            'district' => [
                'required',
                'string'
            ],
            'suburb' => [
                'required',
                'string'
            ],
            'external_number' => [
                'required',
                'integer'
            ],
            'street' => [
                'required',
                'string',
            ]
        ];
    }

    public function authorize()
    {
        return Gate::allows('personal_access');
    }
}
